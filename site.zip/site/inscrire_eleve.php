<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include("connection.php");
    if (isset($_POST["nom"]) && isset($_POST["prenom"]) && isset($_POST["seance_id"])) {
        $nom = $_POST["nom"];
        $prenom = $_POST["prenom"];
        $seance_id = $_POST["seance_id"];

        if (empty($nom) || empty($prenom)) {
            exit("<script>alert('Le nom et le prénom ne peuvent pas être vides.');</script>");
        }


        $query_eleve = "SELECT ideleve FROM eleves WHERE nom = ? AND prenom = ?";
        $stmt_eleve = $mysqli->prepare($query_eleve);
        $stmt_eleve->bind_param("ss", $nom, $prenom);
        $stmt_eleve->execute();
        $result_eleve = $stmt_eleve->get_result();

        if ($result_eleve->num_rows == 0) {
            exit("<script>alert('L\'élève n'existe pas dans la base de données.');</script>");
        }

        $query_seance = "SELECT idseance FROM seances WHERE idseance = ?";
        $stmt_seance = $mysqli->prepare($query_seance);
        $stmt_seance->bind_param("i", $seance_id);
        $stmt_seance->execute();
        $result_seance = $stmt_seance->get_result();

        if ($result_seance->num_rows == 0) {
            exit("<script>alert('L'id de séance n'existe pas dans la base de données.');</script>");
        }

        $query_insert = "INSERT INTO inscription(ideleve, idseance) VALUES (?, ?)";
        $stmt_insert = $mysqli->prepare($query_insert);
        $stmt_insert->bind_param("ii", $ideleve, $seance_id);
        $ideleve = $result_eleve->fetch_assoc()["ideleve"];
        $stmt_insert->execute();
        echo "<script>alert('Inscription réussie.');</script>";


    } else {
        exit("<script>alert('Tous les champs du formulaire doivent être remplis.');</script>");
    }
}


mysqli_close($connect);
?>
