<?php
include("connection.php");
include("ajout_seance.php");
date_default_timezone_set('Europe/Paris');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = date("Y-m-d H:i:s");
    $date_verif = date("Y-m-d H:i:s", strtotime($date . "+14 minutes"));

    $horaire = $_POST["horaire"];
    $place = $_POST["nombre_place"];
    $theme_id = $_POST["theme_id"];
    $duree = $_POST["duree"];

    // Vérification de la date de la séance
    if (!isset($_POST["jour_seance"]) || empty($_POST["jour_seance"])) {
        exit("<script>etape2.click(); document.getElementById('attention_date').style.display='block';</script>");
    }

    $jour_seance_verif = strtotime($_POST["jour_seance"] . " " . $horaire);
    if ($jour_seance_verif === false || $jour_seance_verif < strtotime($date_verif)) {
        exit("<script>etape2.click(); document.getElementById('attention_date').style.display='block';</script>");
    }
    
    // Vérification de l'heure
    $horaire_format = strtotime($horaire);
    $horaire_min = strtotime("08:00");
    $duree_parts = explode(':', $duree);
    $fin_seance = strtotime("+{$duree_parts[0]} hours +{$duree_parts[1]} minutes", $horaire_format);
    $seance_max = strtotime("19:01");

    if ($horaire_format === false || $horaire_format < $horaire_min || $fin_seance > $seance_max) {
        exit("<script>etape2.click(); document.getElementById('attention_horaire').style.display='block';</script>");
    }

    // Vérification de la durée
    $duree_format = strtotime($duree);
    $duree_min = strtotime("00:15");
    $duree_max = strtotime("04:00");
    if ($duree_format === false || $duree_format > $duree_max || $duree_format < $duree_min) {
        exit("<script>etape2.click();document.getElementById('attention_duree').style.display='block';</script>");
    }

    // Vérification du nombre de places
    if (empty($place) || $place > 1000) {
        exit("<script>etape2.click();document.getElementById('attention_place').style.display='block';</script>");
    }

    // Vérification du thème
    $query_select = "SELECT * FROM themes WHERE idtheme = ?";
    $stmt_select = mysqli_prepare($connect, $query_select);
    mysqli_stmt_bind_param($stmt_select, 'i', $theme_id);
    mysqli_stmt_execute($stmt_select);
    $result = mysqli_stmt_get_result($stmt_select);
    if (mysqli_num_rows($result) == 0) {
        exit("<script>alert('$theme_id');etape1.click();document.getElementById('attention_theme').style.display='block';</script>");
    }

    // Insertion de la séance
    $query_insert = "INSERT INTO seances (DateSeance, horaire, duree, EffMax, IdTheme) VALUES (?, ?, ?, ?, ?)";
    $stmt_insert = mysqli_prepare($connect, $query_insert);
    mysqli_stmt_bind_param($stmt_insert, 'sssss', $_POST["jour_seance"], $horaire, $duree, $place, $theme_id);
    if (!mysqli_stmt_execute($stmt_insert)) {
        exit("<scrip>alert('Erreur lors de l'insertion de la séance : " . mysqli_error($connect)."');<s/script>");
    }
    else {
        echo "<script>document.getElementById('theme_ajouter').style.display = 'block';</script>";
    }
    

    mysqli_close($connect);
}
?>
