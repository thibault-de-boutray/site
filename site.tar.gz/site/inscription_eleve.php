<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incription eleve</title>
    <link rel="icon" href="img/eleve.svg" type="image/svg+xml">
    <link rel="stylesheet" href="style/menu.css">
    <link rel="stylesheet" href="style/inscription_eleve.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" type="text/css">
</head>
<body>
    <?php include("menu.php"); ?>
    <main>
        <div class="calendrier" id="calendrier">
            <div class="gauche">
                <div class="mois" id="container_moi">
                    <i class="fa-solid fa-chevron-left" onclick="reculerMois(1)" id="reculer"></i>
                    <p class="text-mois" id="mois-annee"></p>
                    <i class="fa-solid fa-chevron-right"  onclick="ajouterMois(1)"></i>
                </div>
                <div class="horaire-container">
                    <div class="jours" id="contientjours">
                        <i class="fa-solid fa-chevron-left" onclick="enlever7jours()" id="back"></i>
                        <div class="differents-jours">
                            <div class="jour" id="j1">lundi</div>
                            <div class="numero" id="n1"></div>
                        </div>
                        <div class="differents-jours" id="j2">
                            <div class="jour" id="j2">mardi</div>
                            <div class="numero" id="n2"></div>
                        </div>
                        <div class="differents-jours" id="j3">
                            <div class="jour" id="j3">mercredi</div>
                            <div class="numero" id="n3"></div>
                        </div>
                        <div class="differents-jours" id="j4">
                            <div class="jour" id="j4">jeudi</div>
                            <div class="numero" id="n4"></div>
                        </div>
                        <div class="differents-jours" id="j5">
                            <div class="jour" id="j5">vendredi</div>
                            <div class="numero" id="n5" ></div>
                        </div>
                        <div class="differents-jours" id="j6">
                            <div class="jour" id="j6">samedi</div>
                            <div class="numero" id="n6"></div>
                        </div>
                        <div class="differents-jours" id="j7">
                            <div class="jour" id="j7">dimanche</div>
                            <div class="numero" id="n7"></div>
                        </div>
                        <i class="fa-solid fa-chevron-right" onclick="ajouter7jours()"></i>              
                    </div>
                    <div class="planning">
                        <table id="planningTable">
                            <tbody>
                                <tr class="tr">
                                    <td class="each-hour">8h00</td>
                                    <td class="heure" onclick="afficherDroite(0,8)"></td>
                                    <td class="heure" onclick="afficherDroite(1,8)"></td>
                                    <td class="heure" onclick="afficherDroite(2,8)"></td>
                                    <td class="heure" onclick="afficherDroite(3,8)"></td>
                                    <td class="heure" onclick="afficherDroite(4,8)"></td>
                                    <td class="heure" onclick="afficherDroite(5,8)"></td>
                                    <td class="heure" onclick="afficherDroite(6,8)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">9h00</td>
                                    <td class="heure" onclick="afficherDroite(0,9)"></td>
                                    <td class="heure" onclick="afficherDroite(1,9)"></td>
                                    <td class="heure" onclick="afficherDroite(2,9)"></td>
                                    <td class="heure" onclick="afficherDroite(3,9)"></td>
                                    <td class="heure" onclick="afficherDroite(4,9)"></td>
                                    <td class="heure" onclick="afficherDroite(5,9)"></td>
                                    <td class="heure" onclick="afficherDroite(6,9)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">10h00</td>
                                    <td class="heure" onclick="afficherDroite(0,10)"></td>
                                    <td class="heure" onclick="afficherDroite(1,10)"></td>
                                    <td class="heure" onclick="afficherDroite(2,10)"></td>
                                    <td class="heure" onclick="afficherDroite(3,10)"></td>
                                    <td class="heure" onclick="afficherDroite(4,10)"></td>
                                    <td class="heure" onclick="afficherDroite(5,10)"></td>
                                    <td class="heure" onclick="afficherDroite(6,10)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">11h00</td>
                                    <td class="heure" onclick="afficherDroite(0,11)"></td>
                                    <td class="heure" onclick="afficherDroite(1,11)"></td>
                                    <td class="heure" onclick="afficherDroite(2,11)"></td>
                                    <td class="heure" onclick="afficherDroite(3,11)"></td>
                                    <td class="heure" onclick="afficherDroite(4,11)"></td>
                                    <td class="heure" onclick="afficherDroite(5,11)"></td>
                                    <td class="heure" onclick="afficherDroite(6,11)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">12h00</td>
                                    <td class="heure" onclick="afficherDroite(0,12)"></td>
                                    <td class="heure" onclick="afficherDroite(1,12)"></td>
                                    <td class="heure" onclick="afficherDroite(2,12)"></td>
                                    <td class="heure" onclick="afficherDroite(3,12)"></td>
                                    <td class="heure" onclick="afficherDroite(4,12)"></td>
                                    <td class="heure" onclick="afficherDroite(5,12)"></td>
                                    <td class="heure" onclick="afficherDroite(6,12)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">13h00</td>
                                    <td class="heure" onclick="afficherDroite(0,13)"></td>
                                    <td class="heure" onclick="afficherDroite(1,13)"></td>
                                    <td class="heure" onclick="afficherDroite(2,13)"></td>
                                    <td class="heure" onclick="afficherDroite(3,13)"></td>
                                    <td class="heure" onclick="afficherDroite(4,13)"></td>
                                    <td class="heure" onclick="afficherDroite(5,13)"></td>
                                    <td class="heure" onclick="afficherDroite(6,13)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">14h00</td>
                                    <td class="heure" onclick="afficherDroite(0,14)"></td>
                                    <td class="heure" onclick="afficherDroite(1,14)"></td>
                                    <td class="heure" onclick="afficherDroite(2,14)"></td>
                                    <td class="heure" onclick="afficherDroite(3,14)"></td>
                                    <td class="heure" onclick="afficherDroite(4,14)"></td>
                                    <td class="heure" onclick="afficherDroite(5,14)"></td>
                                    <td class="heure" onclick="afficherDroite(6,14)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">15h00</td>
                                    <td class="heure" onclick="afficherDroite(0,15)"></td>
                                    <td class="heure" onclick="afficherDroite(1,15)"></td>
                                    <td class="heure" onclick="afficherDroite(2,15)"></td>
                                    <td class="heure" onclick="afficherDroite(3,15)"></td>
                                    <td class="heure" onclick="afficherDroite(4,15)"></td>
                                    <td class="heure" onclick="afficherDroite(5,15)"></td>
                                    <td class="heure" onclick="afficherDroite(6,15)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">16h00</td>
                                    <td class="heure" onclick="afficherDroite(0,16)"></td>
                                    <td class="heure" onclick="afficherDroite(1,16)"></td>
                                    <td class="heure" onclick="afficherDroite(2,16)"></td>
                                    <td class="heure" onclick="afficherDroite(3,16)"></td>
                                    <td class="heure" onclick="afficherDroite(4,16)"></td>
                                    <td class="heure" onclick="afficherDroite(5,16)"></td>
                                    <td class="heure" onclick="afficherDroite(6,16)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">17h00</td>
                                    <td class="heure" onclick="afficherDroite(0,17)"></td>
                                    <td class="heure" onclick="afficherDroite(1,17)"></td>
                                    <td class="heure" onclick="afficherDroite(2,17)"></td>
                                    <td class="heure" onclick="afficherDroite(3,17)"></td>
                                    <td class="heure" onclick="afficherDroite(4,17)"></td>
                                    <td class="heure" onclick="afficherDroite(5,17)"></td>
                                    <td class="heure" onclick="afficherDroite(6,17)"></td>
                                </tr>
                                <tr>
                                    <td class="each-hour">18h00</td>
                                    <td class="heure" onclick="afficherDroite(0,18)"></td>
                                    <td class="heure" onclick="afficherDroite(1,18)"></td>
                                    <td class="heure" onclick="afficherDroite(2,18)"></td>
                                    <td class="heure" onclick="afficherDroite(3,18)"></td>
                                    <td class="heure" onclick="afficherDroite(4,18)"></td>
                                    <td class="heure" onclick="afficherDroite(5,18)"></td>
                                    <td class="heure" onclick="afficherDroite(6,18)"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="droite">
                <div class="bouton-quitter">
                    <button type="button" onclick="masquerDroite()"><i class="fa-solid fa-xmark"></i></button>
                </div>
                <form class="inscription">
                    <div class="partie-haut">
                        <div class="containter">
                            <h1 class="titre">Votre séance</h1>
                            <div class="separation "></div>
                            <div class="main-containt">
                                <div class="jour element">
                                    <div class="label">
                                        Date : 
                                    </div>                                
                                    <div class="date" id="changejour">
                                        Lundi 8 mars 2024
                                    </div>
                                </div>

                                <div class="horaire element">
                                    <div class="label">
                                        Horaire :
                                    </div>
                                    <div class="heure">
                                        <div id="heureseance">8h00 à</div>
                                        <input id="inputtime" type="time" min="16:00" max="18:00">
                                    </div>    
                                </div>
                                <div for="barre-progress" class="label">Nombre de place :</div>
                                <div class="progress element">
                                    <div class="icone">
                                        <i class="fa-solid fa-message"></i>
                                        <span class="nombre-personne">8/10</span>
                                    </div>
                                </div>
                                <label for="theme" class="label">Choisissez un thème :</label>
                                <div class="theme-container">
                                    <select id="theme" class="theme" name="choix">
                                        <option value="option1" class="souslist">Option 1</option>
                                        <option value="option2" class="souslist">Option 2</option>
                                        <option value="option3" class="souslist">Option 3</option>
                                    </select>
                                    <div class="fleche">
                                        <i class="fa-solid fa-caret-down"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="partie-bas">
                        <h1 class="titre">Identification</h1>
                        <div class="separation"></div>
                        <div class="input">
                                <label for="nom">Le nom :</label>
                                <input type="text" name="nom" id="nom" class="nom">
                                <label for="prenom">Le prenom :</label>
                                <input type="text" name="prenom" id="prenom" class="prenom">
                            </div>
                    </div>
                    <input type="submit" value="valider" class="submit">
                </form>
        </div>
    </div>
    </main>
</body>
<script src="script/inscription_eleve.js"></script>
</html>

