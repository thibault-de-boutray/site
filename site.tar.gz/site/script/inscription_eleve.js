var droite = document.querySelector('.droite');
var paragrapheMoisAnnee = document.getElementById("mois-annee");
var dateActuelle = new Date();
var nomsMois = [
  "janvier", "février", "mars", "avril", "mai", "juin",
  "juillet", "août", "septembre", "octobre", "novembre", "décembre"
];
const joursSemaine = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
var datesSemaine = [];
var heureActuel =dateActuelle.getHours();
var moisActuel = nomsMois[dateActuelle.getMonth()];
var anneeActuelle = dateActuelle.getFullYear();
var texteMoisAnnee = moisActuel + " " + anneeActuelle;
paragrapheMoisAnnee.textContent = texteMoisAnnee;

function masquerDroite() {
    if (droite) {     
        droite.style.display = 'none';   
        document.getElementById('calendrier').style.width = '980px';
        document.querySelector(".gauche").style.width="100%";
        document.querySelector(".gauche").style.borderRadius="20px 20px 20px 20px";
    }
}

function afficherDroite(jour,hour) {
    droite.style.display = 'flex';
    droite.style.borderRadius="0 20px 20px 0px";
    document.querySelector(".gauche").style.borderRadius="20px 0 0 20px";
    document.getElementById('calendrier').style.width = '1400px';
    document.querySelector(".gauche").style.width="65%";
    changerjour(jour);
    changerheure(hour);
}

function actualiserDatesSemaine() {
    var paragrapheMoisAnnee = document.getElementById("mois-annee");
    var texteMoisAnnee = paragrapheMoisAnnee.textContent;
    var mots = texteMoisAnnee.split(" ");
    var mois = mots[0];
    var annee = parseInt(mots[1]);

    if (mois === nomsMois[dateActuelle.getMonth()] && annee === dateActuelle.getFullYear()) {
        var dateActuelleCopy = new Date(dateActuelle);
        var jourSemaineActuel = dateActuelleCopy.getDay();
        var debutSemaineActuelle = new Date(dateActuelleCopy.setDate(dateActuelleCopy.getDate() - jourSemaineActuel));

        for (var i = 0; i < 7; i++) {
            datesSemaine[i] = new Date(debutSemaineActuelle);
            datesSemaine[i].setDate(debutSemaineActuelle.getDate() + i);
        }
    } else {
        var premierJour = new Date(annee, nomsMois.indexOf(mois), 1);
        var jourSemaine = premierJour.getDay();

        for (var i = 0; i < 7; i++) {
            datesSemaine[i] = new Date(premierJour);
            datesSemaine[i].setDate(datesSemaine[i].getDate() + i - (jourSemaine === 0 ? 6 : jourSemaine - 1));
        }
    }
}


function actualiserNumerosJours() {
    for (var i = 0; i < datesSemaine.length; i++) {
        document.getElementById("n" + (i + 1)).textContent = datesSemaine[i].getDate();
    }
}

function ajouterMois(int) {
    document.getElementById("back").style.visibility = "visible";
    var paragrapheMoisAnnee = document.getElementById("mois-annee");
    var texteMoisAnnee = paragrapheMoisAnnee.textContent;
    var mots = texteMoisAnnee.split(" ");
    var mois = mots[0];
    var annee = parseInt(mots[1]);
    var indexMois = nomsMois.indexOf(mois.toLowerCase());
    if (indexMois === 11) {
      indexMois = 0;
      annee++;
    } else {
      indexMois++;
    }
    paragrapheMoisAnnee.textContent = nomsMois[indexMois] + " " + annee;
    document.getElementById("reculer").style.visibility = "visible";
    document.getElementById("container_moi").style.justifyContent="space-evenly";
    if (int==1){
        actualiserDatesSemaine();
    } 
    actualiserNumerosJours();
    moisavant();
}

function reculerMois(int) {
    var paragrapheMoisAnnee = document.getElementById("mois-annee");
    var texteMoisAnnee = paragrapheMoisAnnee.textContent;
    var mots = texteMoisAnnee.split(" ");
    var mois = mots[0];
    var annee = parseInt(mots[1]);
    var indexMois = nomsMois.indexOf(mois.toLowerCase());
    if (indexMois === 0) {
      indexMois = 11;
      annee--;
    } else {
      indexMois--;
    }
    paragrapheMoisAnnee.textContent = nomsMois[indexMois] + " " + annee;
    if (indexMois === dateActuelle.getMonth()) {
        document.getElementById("reculer").style.visibility = "hidden";
        document.getElementById("back").style.visibility = "hidden";
        document.getElementById("container_moi").style.justifyContent="center";
    }
    if (int==1){
        actualiserDatesSemaine();
    } 
    actualiserNumerosJours();
    moisavant();
}
function ajouter7jours() {
    document.getElementById("back").style.visibility = "visible";
    for (var i = 0; i < datesSemaine.length; i++) {
        datesSemaine[i].setDate(datesSemaine[i].getDate() + 7);
    }
    var moisActuel = nomsMois.indexOf(paragrapheMoisAnnee.textContent.split(" ")[0].toLowerCase());
    if (datesSemaine[0].getMonth() !== moisActuel) {
        ajouterMois(0);
    }
    actualiserNumerosJours();
    moisavant();
}

function enlever7jours() {
    for (var i = 0; i < datesSemaine.length; i++) {
        datesSemaine[i].setDate(datesSemaine[i].getDate() - 7);
    }
    actualiserNumerosJours();
    var moisdiv = nomsMois.indexOf(paragrapheMoisAnnee.textContent.split(" ")[0].toLowerCase());
    if (datesSemaine[datesSemaine.length - 1].getMonth() !== moisdiv) {
        reculerMois(0);
    }
    var copy= new Date(datesSemaine[6]);
    copy.setDate(datesSemaine[6].getDate()-7);
    if (copy<dateActuelle){
        document.getElementById("back").style.visibility="hidden";
    }
    moisavant();
}

function moisavant() {
    var paragrapheMoisAnnee = document.getElementById("mois-annee");
    var texteMoisAnnee = paragrapheMoisAnnee.textContent;
    var mots = texteMoisAnnee.split(" ");
    var mois = mots[0];
    var indexMois = nomsMois.indexOf(mois.toLowerCase());
    
    for (var i = 0; i < 7; i++) {
        if (datesSemaine[i].getMonth() !== indexMois) {
            document.getElementById("n" + (i + 1)).style.color = "black";
            document.getElementById("j" + (i + 1)).style.color = "black";
            document.getElementById("n" + (i + 1)).style.fontWeight = "900";
            document.getElementById("j" + (i + 1)).style.fontWeight = "900";
        } else {
            document.getElementById("n" + (i + 1)).style.color = "rgb(95, 91, 91)";
            document.getElementById("n" + (i + 1)).style.fontWeight = "0";
            document.getElementById("j" + (i + 1)).style.color = "rgb(95, 91, 91)";
            document.getElementById("j" + (i + 1)).style.fontWeight = "0";
        }
    }
}
function changerjour(int){
    var lejour=joursSemaine[int];
    var lemois=nomsMois[datesSemaine[int].getMonth()];
    var lenumero=datesSemaine[int].getDate();
    var lannee=datesSemaine[int].getFullYear()
    document.getElementById("changejour").innerHTML=lejour+" "+lenumero+" "+lemois+" "+lannee;
}
function changerheure(heure){
    if (document.getElementById("heureseance")){
        document.getElementById("heureseance").innerHTML=heure+":00 à";
    }
    if (document.getElementById("inputtime")){
        document.getElementById("inputtime").min=heure+":00";
        document.getElementById("inputtime").value=(heure+1)+":00";
    }
    
}
function fusionnerLignes(colonne, premiereLigne, derniereLigne) {
    var table = document.getElementById("planningTable");

    for (var i = premiereLigne + 1; i <= derniereLigne; i++) {
        var row = table.rows[i];
        var cell = row.cells[colonne];
        cell.style.display = "none";
    }

    var premierCellule = table.rows[premiereLigne].cells[colonne];
    premierCellule.rowSpan = derniereLigne - premiereLigne + 1;
}
fusionnerLignes(2,2, 4);

actualiserDatesSemaine();
actualiserNumerosJours();
moisavant();
masquerDroite();

